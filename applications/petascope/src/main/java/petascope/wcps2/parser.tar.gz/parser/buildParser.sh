#!/bin/bash
rm *.java *.class *.tokens
export antlr4="java -jar /usr/local/lib/antlr-4.1-complete.jar"
$antlr4 -package petascope.wcps2.parser wcps.g4
$antlr4 -package petascope.wcps2.parser -no-listener -visitor wcps.g4
javac *.java
