package petascope.wcps2.parser;

import org.antlr.v4.runtime.misc.NotNull;
import petascope.wcps2.translator.ForClause;
import petascope.wcps2.translator.ForClauseList;
import petascope.wcps2.translator.IParseeTreeNode;

import java.util.ArrayList;

/**
 * Author: Vlad Merticariu <a href="mailto:vlad@flanche.net">vlad@flanche.net</a>
 * Date: 2/2/14
 * Time: 10:03 PM
 */
public class wcpsEvaluator extends wcpsBaseVisitor<IParseeTreeNode> {
    @Override
    public IParseeTreeNode visitForClauseLabel(@NotNull wcpsParser.ForClauseLabelContext ctx) {
        return new ForClause(ctx.COVERAGE_VARIABLE_NAME().getText(), ctx.COVERAGE_NAME().getText());
    }

    @Override
    public IParseeTreeNode visitForClauseListLabel(@NotNull wcpsParser.ForClauseListLabelContext ctx) {
        ArrayList<IParseeTreeNode> forClauses = new ArrayList<IParseeTreeNode>();
        for(wcpsParser.ForClauseContext currentClause : ctx.forClause()){
            forClauses.add(visit(currentClause));
        }
        return new ForClauseList(forClauses);
    }

    @Override
    public IParseeTreeNode visitProcessingExpression(@NotNull wcpsParser.ProcessingExpressionContext ctx) {
        return super.visitProcessingExpression(ctx);    //To change body of overridden methods use File | Settings | File Templates.
    }
}
